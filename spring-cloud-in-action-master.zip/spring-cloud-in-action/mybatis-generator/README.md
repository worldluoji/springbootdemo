1.生成代码 请执行generatorConfig.xml 文件

maven执行 参数：
base directory ：${workspace_loc:/mybatis-generator}
goals：mybatis-generator:generate
其他放空

